@extends('layout.main')

@section('content')
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-box">
                    <div class="form-title-wrap">
                        <div>
                            <h3 class="title">{{ $subTitle }}</h3>
                            <p class="font-size-14">Form {{ $subTitle }}</p>
                        </div>
                    </div>
                    <div class="form-content">
                        <div class="contact-form-action">
                            <form action="/setting/{{ $biodata->id_setting }}" method="Post" enctype="multipart/form-data">
                                @csrf
                                <div class="row">
                                    <div class="col-md-12">
                                        @if (session('berhasil'))    
                                            <div class="alert bg-primary text-white alert-dismissible">
                                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                                <h4><i class="icon fa fa-ban"></i> Berhasil!</h4>
                                                {{ session('berhasil') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 form-group">
                                        <div class="input-box">
                                            <label class="label-text">Nama Website</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="nama_website" placeholder="Masukkan Nama Website" value="{{ $biodata->nama_website }}" autofocus>
                                            </div>
                                            @error('nama_website')
                                            <div style="margin-top: -16px">
                                                <small class="text-danger">{{ $message }}</small>
                                            </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Email</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="email" placeholder="Masukkan Email" value="{{ $biodata->email }}">
                                            </div>
                                            @error('email')
                                            <div style="margin-top: -16px">
                                                <small class="text-danger">{{ $message }}</small>
                                            </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Nomor Telepon</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="nomor_telepon" placeholder="Masukkan Nomor Telepon" value="{{ $biodata->nomor_telepon }}">
                                            </div>
                                            @error('nomor_telepon')
                                            <div style="margin-top: -16px">
                                                <small class="text-danger">{{ $message }}</small>
                                            </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Alamat</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="alamat" placeholder="Masukkan Alamat" value="{{ $biodata->alamat }}">
                                            </div>
                                            @error('alamat')
                                            <div style="margin-top: -16px">
                                                <small class="text-danger">{{ $message }}</small>
                                            </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Logo</label>
                                            <div class="form-group">
                                                <input type="file" name="logo" class="form-control" maxlength="3" required>
                                            </div>
                                            @error('logo')
                                            <div style="margin-top: -16px">
                                                <small class="text-danger">{{ $message }}</small>
                                            </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            {{-- <label class="label-text">Logo</label> --}}
                                            <div class="form-group">
                                                <img src="{{ asset('foto_biodata/'.$biodata->logo) }}" width="60%" alt="Logo">
                                            </div>
                                        </div>
                                    </div>
                                    {{-- <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Power Harga</label>
                                            <div class="form-group d-flex align-items-center">
                                                <label for="radio-5" class="radio-trigger mb-0 font-size-14 mr-3">
                                                    <input type="radio" id="radio-5" value="On" name="power_harga" @if($biodata->power_harga === 'On')checked @endif>
                                                    <span class="checkmark"></span>
                                                    <span>On</span>
                                                </label>
                                                <label for="radio-6" class="radio-trigger mb-0 font-size-14">
                                                    <input type="radio" id="radio-6" value="Off" name="power_harga" @if($biodata->power_harga === 'Off')checked @endif>
                                                    <span class="checkmark"></span>
                                                    <span>Off</span>
                                                </label>
                                            </div>
                                            @error('power_harga')
                                            <div style="margin-top: -16px">
                                                <small class="text-danger">{{ $message }}</small>
                                            </div>
                                            @enderror
                                        </div>
                                    </div> --}}
                                </div>
                                <div class="btn-box pt-3 pb-4">
                                    <center>
                                        <button type="submit" class="theme-btn theme-btn-small">Simpan</button>
                                    </center>
                                </div>
                            </form>
                        </div>
                    </div>
                </div><!-- end form-box -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        
        {{-- footer --}}
        @include('layout.footer')
        {{-- end footer --}}
    </div>
</div>
@endsection