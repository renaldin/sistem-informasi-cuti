<div class="row align-items-center">
    <div class="col-lg-7">
        <div class="copy-right padding-top-30px">
            <p class="copy__desc">
                &copy; Copyright {{$biodata->nama_website}} {{ date('Y') }}. di desain oleh
                 <a href="/">Admin {{$biodata->nama_website}}</a>
            </p>
        </div>
    </div>
</div>