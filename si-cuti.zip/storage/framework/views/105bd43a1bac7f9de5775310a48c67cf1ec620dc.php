

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-box">
                    <div class="form-title-wrap">
                        <div>
                            <h3 class="title"><?php echo e($subTitle); ?></h3>
                            <p class="font-size-14">Silahkan lihat data surat di tabel bawah!</p>
                        </div>
                    </div>
                    
                    <div class="form-title-wrap">
                        <div>
                            <table>
                                <tr>
                                    <td colspan="3">Keterangan Tanggal:</td>
                                </tr>
                                <tr>
                                    <td><span class="badge badge-danger py-1 px-2">Merah</span></td>
                                    <td width="5px"></td>
                                    <td>Berjarak kurang dari 30 menit</td>
                                </tr>
                            </table>
                            
                        </div>
                    </div>
                    <div class="form-content">
                        <div class="table-form table-responsive">
                            
                            
                            <table class="table" id="example2">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">No Surat</th>
                                        <th scope="col">Perihal</th>
                                        <th scope="col">Tanggal</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;?>
                                    <?php
                                    date_default_timezone_set('Asia/Jakarta');
                                        function reminder($tanggal) {
                                            // Mendapatkan waktu sekarang
                                            $currentDateTime = date('Y-m-d H:i:s');

                                            // Mengubah string waktu menjadi waktu dalam detik
                                            $timestamp = strtotime($currentDateTime);
                                            $tanggal_surat = strtotime($tanggal);

                                            $sekarang = floor($timestamp / 60);
                                            $waktu_surat = floor($tanggal_surat / 60);
                                            
                                            // Menghitung selisih waktu antara jam tertentu dengan jam sekarang
                                            $selisih = $waktu_surat - $sekarang;
                                            return $selisih;
                                        }
                                    ?>
                                    <?php $__currentLoopData = $dataSurat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->id_user == $user->id_user && $item->status_surat == 'Sudah Dikirim'): ?> 
                                    <tr>
                                        <th scope="row"><?php echo e($no++); ?></th>
                                        <td><?php echo e($item->no_surat); ?></td>
                                        <td><?php echo e($item->perihal_surat); ?></td>
                                        <td>
                                            <?php if(reminder($item->tanggal) >= 1440): ?>
                                                <span class="badge badge-success py-1 px-2">
                                                    <?php echo e($item->tanggal); ?>

                                                </span>
                                            <?php elseif(reminder($item->tanggal) >= 30): ?>
                                                <span class="badge badge-warning py-1 px-2">
                                                    <?php echo e($item->tanggal); ?>

                                                </span>
                                            <?php elseif(reminder($item->tanggal) >= 0): ?>
                                                <span class="badge badge-danger py-1 px-2">
                                                    <?php echo e($item->tanggal); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="badge badge-primary py-1 px-2">
                                                    <?php echo e($item->tanggal); ?>

                                                </span>
                                            <?php endif; ?>    
                                        </td>
                                        <td><?php echo e($item->status_terlaksana); ?> Terlaksana</td>
                                        <td>
                                            <div class="table-content">
                                                <button type="button" class="theme-btn theme-btn-small mb-1" data-toggle="modal" data-target="#detail<?php echo e($item->id_surat); ?>" data-toggle="tooltip" data-placement="top" title="Detail"><i class="la la-eye"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div><!-- end form-box -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="cetak" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content modal-sm">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Rentang Tanggal</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="/cetak-surat" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="tanggal_mulai">Mulai Dari Tanggal</label>
              <input type="date" class="form-control <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal_mulai" id="tanggal_mulai" placeholder="Masukkan Tanggal Mulai" required>
              <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <small class="form-text text-danger"><?php echo e($message); ?></small>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <label for="tanggal_akhir">Sampai Dengan</label>
              <input type="date" class="form-control <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal_akhir" id="tanggal_akhir" placeholder="Masukkan Tanggal Akhir" required>
              <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <small class="form-text text-danger"><?php echo e($message); ?></small>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
          <button type="submit" class="btn btn-primary">Cetak</button>
        </div>
      </form>
      </div>
    </div>
</div>


<?php $__currentLoopData = $dataSurat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="detail<?php echo e($item->id_surat); ?>"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Detail Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-lg-12">
                    <table>
                        <tr>
                            <th width="150px">No. Surat</th>
                            <td width="20px" class="text-center">:</td>
                            <td><?php echo e($item->no_surat); ?></td>
                        </tr>
                        <tr>
                            <th>Perihal</th>
                            <td>:</td>
                            <td><?php echo e($item->perihal_surat); ?></td>
                        </tr>
                        <tr>
                            <th>Hari</th>
                            <td>:</td>
                            <td><?php echo e($item->hari); ?></td>
                        </tr>
                        <tr>
                            <th>Tanggal Surat</th>
                            <td>:</td>
                            <td><?php echo e($item->tanggal); ?></td>
                        </tr>
                        <tr>
                            <th>Tempat</th>
                            <td>:</td>
                            <td><?php echo e($item->tempat); ?></td>
                        </tr>
                        <tr>
                            <th>Jenis Surat</th>
                            <td>:</td>
                            <td><?php echo e($item->jenis_surat); ?></td>
                        </tr>
                        <tr>
                            <th>Status Surat</th>
                            <td>:</td>
                            <td><?php echo e($item->status_terlaksana); ?> Terlaksana</td>
                        </tr>
                    </table>
                </div>
                <div class="col-lg-12 mt-3 text-center">
                    <label class="label-text">File Surat</label>
                    <iframe src="<?php echo e(asset('file_surat/'.$item->file_surat)); ?>" frameborder="0" scrolling="auto" width="100%" height="500px"></iframe>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
        </div>
        </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/ketuajurusan/surat/data.blade.php ENDPATH**/ ?>