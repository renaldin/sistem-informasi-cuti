

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-box">
                    <div class="form-title-wrap">
                        <div>
                            <h3 class="title"><?php echo e($subTitle); ?> <?php echo e($detail->nama); ?></h3>
                            <p class="font-size-14"><?php echo e($subTitle); ?></p>
                        </div>
                    </div>
                    <div class="form-content">
                        <div class="contact-form-action">
                            <form action="/izin-atasan/<?php echo e($detail->id_pengajuan_cuti); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text">Pertimbangan Atasan Langsung **</label>
                                            <div class="form-group select-contain w-100">
                                                <select class="select-contain-select" name="pertimbangan_atasan" id="pertimbangan_atasan" required>
                                                    <option value="">-- Pilih --</option>
                                                    <option value="DISETUJUI">DISETUJUI</option>
                                                    <option value="PERUBAHAN">PERUBAHAN</option>
                                                    <option value="DITANGGUHKAN">DITANGGUHKAN</option>
                                                    <option value="TIDAK DISETUJUI">TIDAK DISETUJUI</option>
                                                </select>
                                            </div>
                                            <?php $__errorArgs = ['pertimbangan_atasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 alasan_pertimbangan_atasan">
                                        
                                    </div>
                                </div>
                                <div class="col-lg-12 mt-3 text-center">
                                    <a href="/perizinan-cuti-atasan" class="theme-btn theme-btn-small theme-btn-transparent">Kembali</a>
                                    <button type="submit" class="theme-btn theme-btn-small">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div><!-- end form-box -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        
        
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/atasan/perizinancuti/permission.blade.php ENDPATH**/ ?>