

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-box">
                    <div class="form-title-wrap">
                        <div>
                            <h3 class="title"><?php echo e($subTitle); ?></h3>
                            <p class="font-size-14">Form <?php echo e($subTitle); ?></p>
                        </div>
                    </div>
                    <div class="form-content">
                        <div class="contact-form-action">
                            <form action="/edit-surat/<?php echo e($detail->id_surat); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">No. Surat</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="no_surat" placeholder="Masukkan No. Surat" value="<?php echo e($detail->no_surat); ?>">
                                            </div>
                                            <?php $__errorArgs = ['no_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Perihal Surat</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="perihal_surat" placeholder="Masukkan Perihal Surat" value="<?php echo e($detail->perihal_surat); ?>">
                                            </div>
                                            <?php $__errorArgs = ['perihal_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Hari</label>
                                            <div class="form-group select-contain w-100">
                                                <select class="select-contain-select" name="hari" id="hari" required>
                                                    <?php if($detail->hari): ?>
                                                    <option value="<?php echo e($detail->hari); ?>"><?php echo e($detail->hari); ?></option>
                                                    <?php else: ?>
                                                    <option value="">-- Pilih --</option>
                                                    <?php endif; ?>
                                                    <option value="Senin">Senin</option>
                                                    <option value="Selasa">Selasa</option>
                                                    <option value="Rabu">Rabu</option>
                                                    <option value="Kamis">Kamis</option>
                                                    <option value="Jum'at">Jum'at</option>
                                                    <option value="Sabtu">Sabtu</option>
                                                    <option value="Minggu">Minggu</option>
                                                </select>
                                            </div>
                                            <?php $__errorArgs = ['hari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Tanggal</label>
                                            <div class="form-group">
                                                <input class="form-control" type="datetime-local" name="tanggal" placeholder="Masukkan Tanggal" value="<?php echo e($detail->tanggal); ?>">
                                            </div>
                                            <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Tempat</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="tempat" placeholder="Masukkan Tempat" value="<?php echo e($detail->tempat); ?>">
                                            </div>
                                            <?php $__errorArgs = ['tempat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Jenis Surat</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="jenis_surat" placeholder="Masukkan Jenis Surat" value="<?php echo e($detail->jenis_surat); ?>">
                                            </div>
                                            <?php $__errorArgs = ['jenis_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Status Terlaksana</label>
                                            <div class="form-group select-contain w-100">
                                                <select class="select-contain-select" name="status_terlaksana" id="status_terlaksana" required>
                                                    <?php if($detail->status_terlaksana): ?>
                                                        <option value="<?php echo e($detail->status_terlaksana); ?>"><?php echo e($detail->status_terlaksana); ?></option>
                                                    <?php else: ?>
                                                        <option value="">-- Pilih --</option>
                                                    <?php endif; ?>
                                                    <option value="Sudah">Sudah</option>
                                                    <option value="Belum">Belum</option>
                                                    <option value="Tidak">Tidak</option>
                                                </select>
                                            </div>
                                            <?php $__errorArgs = ['status_terlaksana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">File Surat</label>
                                            <div class="form-group">
                                                <input type="file" name="file_surat" class="form-control" maxlength="3">
                                            </div>
                                            <?php $__errorArgs = ['file_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                </div>
                                <div class="col-lg-12 mt-3 text-center">
                                    <a href="/kelola-surat" class="theme-btn theme-btn-small theme-btn-transparent">Kembali</a>
                                    <button type="submit" class="theme-btn theme-btn-small">Simpan</button>
                                </div>
                                <div class="col-lg-12 mt-3 text-center">
                                    <label class="label-text">File Surat</label>
                                    <iframe src="<?php echo e(asset('file_surat/'.$detail->file_surat)); ?>" frameborder="0" scrolling="auto" width="100%" height="500px"></iframe>
                                </div>
                            </form>
                        </div>
                    </div>
                </div><!-- end form-box -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        
        
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/admin/surat/edit.blade.php ENDPATH**/ ?>