

<?php $__env->startSection('content'); ?>
<section>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-box">
                <div class="form-title-wrap">
                    <div>
                        <h3 class="title"><?php echo e($subTitle); ?></h3>
                        <p class="font-size-14">Form <?php echo e($subTitle); ?></p>
                    </div>
                </div>
                <div class="form-content">
                    <div class="contact-form-action">
                        <form <?php if($form === 'Tambah'): ?> action="/tambah-partner"  <?php else: ?> action="/edit-partner/<?php echo e($partner->id_partner); ?>" <?php endif; ?> method="Post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Nama Partner</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="text" name="nama_partner" placeholder="Masukkan Nama Partner" <?php if($form === 'Edit'): ?> value="<?php echo e($partner->nama_partner); ?>" <?php elseif($form === 'Detail'): ?> value="<?php echo e($partner->nama_partner); ?>" disabled <?php elseif($form === 'Tambah'): ?> value="<?php echo e(old('nama_partner')); ?>" <?php endif; ?> autofocus>
                                        </div>
                                        <?php $__errorArgs = ['nama_partner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Gambar</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="file" name="gambar" <?php if($form === 'Detail'): ?> disabled <?php endif; ?>>
                                        </div>
                                        <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <?php if($form === 'Detail'): ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Gambar</label>
                                        <div class="form-group">
                                            <img src="<?php echo e(asset('foto_partner/'.$partner->gambar)); ?>" width="100%" alt="<?php echo e($partner->gambar); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="btn-box pt-3 pb-4">
                                <center>
                                    <button type="submit" class="theme-btn w-50">Simpan</button>
                                </center>
                            </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div><!-- end form-box -->
        </div><!-- end col-lg-12 -->
    </div><!-- end row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/admin/partner/form.blade.php ENDPATH**/ ?>