<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title><?php echo e($title); ?></title>

        <style>
            @page  { size: A4 }
          
            h3 {
                font-weight: bold;
                text-align: center;
                font-size: 16px;
                line-height: inherit;
                font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
            }
          
            .table {
                border-collapse: collapse;
                width: 100%;
                font-size: 10pt;
                line-height: inherit;
                font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
            }
          
            .table th {
                padding: 1px 1px;
                border:1px solid #000000;
            }
          
            .table td {
                padding: 1px 1px;
                border:1px solid #000000;
            }
          
            .text-center {
                text-align: center;
            }
        </style>
		<style>
			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 1px;
				border: 1px solid #eee;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 12px;
				line-height: 8px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
			}

			.invoice-box table {
				width: 100%;
				line-height: inherit;
				text-align: left;
			}

			.invoice-box table td {
				padding: 1px;
				vertical-align: top;
			}

			.invoice-box table tr td:nth-child(2) {
				text-align: left;
			}

			.invoice-box table tr.top table td {
				padding-bottom: 1px;
			}

			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}

			.invoice-box table tr.information table td {
				padding-bottom: 1px;
			}

			.invoice-box table tr.heading td {
				background: #eee;
				border-bottom: 1px solid #ddd;
				font-weight: bold;
			}

			.invoice-box table tr.details td {
				padding-bottom: 1px;
			}

			.invoice-box table tr.item td {
				border-bottom: 1px solid #eee;
			}

			.invoice-box table tr.item.last td {
				border-bottom: none;
			}

			.invoice-box table tr.total td:nth-child(2) {
				border-top: 2px solid #eee;
				font-weight: bold;
			}

			@media  only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 100%;
					display: block;
					text-align: center;
				}

				.invoice-box table tr.information table td {
					width: 100%;
					display: block;
					text-align: center;
				}
			}

			/** RTL **/
			.invoice-box.rtl {
				direction: rtl;
				font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
			}

			.invoice-box.rtl table {
				text-align: left;
			}

			.invoice-box.rtl table tr td:nth-child(2) {
				text-align: left;
			}
		</style>
	</head>

	<body>
        <section>
            <div class="invoice-box">
                <table cellpadding="0" cellspacing="0">
                    <tr class="top">
                        <td colspan="2">
                            <table>
                                <tr>
                                    <td width="340PX">
                                        
                                    </td>
                                    <td>
                                        PERATURAN BADAN KEPEGAWAIAN NEGARA
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        REPUBLIK INDONESIA
                                    </td>
                                <tr>
                                <tr>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        NOMOR 24 TAHUN 2017
                                    </td>
                                <tr>
                                <tr>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        TENTANG
                                    </td>
                                <tr>
                                <tr>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        TATA CARA PEMBERIAN CUTI PEGAWAI NEGERI SIPIL
                                    </td>
                                <tr>
                            </table>
                            <table>
                                <tr>
                                    <td width="460PX">
                                    </td>
                                    <td>
                                        Subang ...................................
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                    </td>
                                    <td>
                                        Kepada
                                    </td>
                                <tr>
                                <tr>
                                    <td>
                                    </td>
                                    <td>
                                        Yth.
                                    </td>
                                <tr>
                                <tr>
                                    <td>
                                    </td>
                                    <td>
                                        di ...............................................
                                    </td>
                                <tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </div>
        </section>

        <section class="sheet padding-10mm" style="margin-top: -10px;">
            <div style="text-align: center;">
                <p style="font-size: 10pt;"><strong>FORMULIR PERMINTAAN DAN PEMBERIAN CUTI</strong></p>
            </div>

            <div>
                <table class="table" style="width: 100%; border: #424141 1px solid;">
                    <tr>
                        <th colspan="4" style="text-align: left; border-left: 0;">I. DATA PEGAWAI</th>
                    </tr>
                    <tr>
                        <td >Nama</td>
                        <td ><?php echo e($detail->nama); ?></td>
                        <td >NIP</td>
                        <td ><?php echo e($detail->nip); ?></td>
                    </tr>
                    <tr>
                        <td >Jabatan</td>
                        <td ><?php echo e($detail->jabatan); ?></td>
                        <td >Masa Kerja</td>
                        <td ><?php echo e($detail->masa_kerja); ?></td>
                    </tr>
                    <tr>
                        <td >Unit Kerja</td>
                        <td colspan="3" ><?php echo e($detail->unit_kerja); ?> POLITEKNIK NEGERI SUBANG</td>
                    </tr>
                </table>
            </div>
      
            <div style="margin-top: 10px;">
                <table class="table" style="width: 100%; border: #424141 1px solid;">
                    <tr>
                        <th colspan="4" style="text-align: left; border-left: 0;">II. JENIS CUTI YANG DIAMBIL **</th>
                    </tr>
                    <tr>
                        <td >1. Cuti Tahunan</td>
                        <td ><?php if($detail->jenis_cuti === 'Cuti Tahunan'): ?> Ya <?php endif; ?></td>
                        <td >2. Cuti Besar</td>
                        <td ><?php if($detail->jenis_cuti === 'Cuti Besar'): ?> Ya <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td >3. Cuti Sakit</td>
                        <td ><?php if($detail->jenis_cuti === 'Cuti Sakit'): ?> Ya <?php endif; ?></td>
                        <td >4. Cuti Melahirkan</td>
                        <td ><?php if($detail->jenis_cuti === 'Cuti Melahirkan'): ?> Ya <?php endif; ?></td>
                    </tr>
                    <tr>
                        <td >5. Cuti Karena Alasan Penting</td>
                        <td ><?php if($detail->jenis_cuti === 'Cuti Karena Alasan Penting'): ?> Ya <?php endif; ?></td>
                        <td >6. Cuti di Luar Tanggungan Negara</td>
                        <td ><?php if($detail->jenis_cuti === 'Cuti di Luar Tanggungan Negara'): ?> Ya <?php endif; ?></td>
                    </tr>
                </table>
            </div>

            <div style="margin-top: 10px;">
                <table class="table" style="width: 100%; border: #424141 1px solid;">
                    <tr>
                        <th style="text-align: left; border-left: 0;">III. ALASAN CUTIL</th>
                    </tr>
                    <tr>
                        <td ><?php echo e($detail->alasan_cuti); ?></td>
                    </tr>
                </table>
            </div>

            <div style="margin-top: 10px;">
                <table class="table" style="width: 100%; border: #424141 1px solid;">
                    <tr>
                        <th colspan="6" style="text-align: left; border-left: 0;">IV. LAMANYA CUTI</th>
                    </tr>
                    <tr>
                        <td >Selama</td>
                        <td ><?php echo e($detail->lama_cuti); ?> (<span <?php if($detail->jenis_waktu !== 'hari'): ?> style="text-decoration: line-through;" <?php endif; ?>>hari</span>/<span <?php if($detail->jenis_waktu !== 'bulan'): ?> style="text-decoration: line-through;" <?php endif; ?>>bulan</span>/<span <?php if($detail->jenis_waktu !== 'tahun'): ?> style="text-decoration: line-through;" <?php endif; ?>>tahun</span>)*</td>
                        <td >Mulai Tanggal</td>
                        <td ><?php echo e($detail->mulai_tanggal); ?></td>
                        <td >s.d</td>
                        <td ><?php echo e($detail->akhir_tanggal); ?></td>
                    </tr>
                </table>
            </div>

            <div style="margin-top: 10px;">
                <table class="table" style="width: 100%; border: #424141 1px solid;">
                    <tr>
                        <th colspan="5" style="text-align: left; border-left: 0;">V. CATATAN CUTI ***</th>
                    </tr>
                    <tr>
                        <td colspan="3" >1. CUTI TAHUNAN</td>
                        <td >2. CUTI BESAR</td>
                        <td ><?php echo e($detail->cuti_besar); ?></td>
                    </tr>
                    <tr>
                        <td >Tahun</td>
                        <td >Sisa</td>
                        <td >Keterangan</td>
                        <td >3. CUTI SAKIT</td>
                        <td ><?php echo e($detail->cuti_sakit); ?></td>
                    </tr>
                    <tr>
                        <td >N-2</td>
                        <td ><?php echo e($detail->cuti_n_2); ?></td>
                        <td ><?php echo e($detail->keterangan_n_2); ?></td>
                        <td >4. CUTI MELAHIRKAN</td>
                        <td ><?php echo e($detail->cuti_melahirkan); ?></td>
                    </tr>
                    <tr>
                        <td >N-1</td>
                        <td ><?php echo e($detail->cuti_n_1); ?></td>
                        <td ><?php echo e($detail->keterangan_n_1); ?></td>
                        <td >5. CUTI KARENA ALASAN PENTING</td>
                        <td ><?php echo e($detail->cuti_karena_alasan_penting); ?></td>
                    </tr>
                    <tr>
                        <td >N</td>
                        <td ><?php echo e($detail->cuti_n); ?></td>
                        <td ><?php echo e($detail->keterangan_n); ?></td>
                        <td >6. CUTI DI LUAR TANGGUNGAN NEGARA</td>
                        <td ><?php echo e($detail->cuti_diluar_tanggungan_negara); ?></td>
                    </tr>
                </table>
            </div>

            <div style="margin-top: 10px;">
                <table class="table" style="width: 100%; border: #424141 1px solid;">
                    <tr>
                        <th colspan="3" style="text-align: left; border-left: 0;">VI. ALAMAT SELAMA MENJALANKAN CUTI</th>
                    </tr>
                    <tr>
                        <td width="420px" rowspan="2" ><?php echo e($detail->alamat_selama_cuti); ?></td>
                        <td >TELP</td>
                        <td ><?php echo e($detail->nomor_telepon); ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center; border-top: 1px solid #424141; border-bottom: 1px solid #424141; border-left: 1px solid #424141;">
                            Hormat saya,
                            <br>
                            <?php if($detail->nip !== null): ?>
                                <img src="https://himmi-polsub.com/gambar/tanda_tangan/pegawai.png" width="29%" alt="">
                            <?php endif; ?>
                            <br>
                            ( <?php echo e($detail->nama); ?> ) <br>
                            NIP <?php echo e($detail->nip); ?>

                        </td>
                    </tr>
                </table>
            </div>

            <div style="margin-top: 10px;">
                <table class="table" style="width: 100%; border-top: #424141 1px solid; border-right: #424141 1px solid;">
                    <tr>
                        <th colspan="4" style="text-align: left; border-left: 1px solid #424141;">VII. PERTIMBANGAN ATASAN LANGSUNG **</th>
                    </tr>
                    <tr>
                        <td width="80px" >DISETUJUI</td>
                        <td >PERUBAHAN ****</td>
                        <td >DITANGGUHKAN ****</td>
                        <td width="276px" >TIDAK DISETUJUI ****</td>
                    </tr>
                    <tr>
                        <td ><?php if($detail->pertimbangan_ketua_jurusan === 'DISETUJUI'): ?>Ya. <?php endif; ?></td>
                        <td ><?php if($detail->pertimbangan_ketua_jurusan === 'PERUBAHAN'): ?>Ya. <?php echo e($detail->alasan_pertimbangan_ketua_jurusan); ?><?php endif; ?></td>
                        <td ><?php if($detail->pertimbangan_ketua_jurusan === 'DITANGGUHKAN'): ?>Ya. <?php echo e($detail->alasan_pertimbangan_ketua_jurusan); ?><?php endif; ?></td>
                        <td ><?php if($detail->pertimbangan_ketua_jurusan === 'TIDAK DISETUJUI'): ?>Ya. <?php echo e($detail->alasan_pertimbangan_ketua_jurusan); ?><?php endif; ?></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: left; border-left: 0px solid; border-bottom: 0px solid;"></td>
                        <td style="text-align: center; border-top: 1px solid #424141; border-bottom: 1px solid #424141; border-left: 1px solid #424141;">
                            Hormat saya,
                            <br>
                            <?php if($detail->ketua_jurusan !== null): ?>
                                <img src="https://himmi-polsub.com/gambar/tanda_tangan/kajur.png" width="29%" alt="">
                            <?php endif; ?>
                            <br>
                            ( <?php if($detail->ketua_jurusan === null): ?> .............................................. <?php else: ?> <?php echo e($detail->ketua_jurusan); ?> <?php endif; ?> ) <br>
                            NIP <?php if($detail->nip_ketua_jurusan === null): ?> .............................................. <?php else: ?> <?php echo e($detail->nip_ketua_jurusan); ?> <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>

            <div style="margin-top: 10px;">
                <table class="table" style="width: 100%; border-top: #424141 1px solid; border-right: #424141 1px solid;">
                    <tr>
                        <th colspan="4" style="text-align: left; border-left: 1px solid #424141;">VIII. KEPUTUSAN PEJABAT YANG BERWENANG MEMBERIIKAN CUTI **</th>
                    </tr>
                    <tr>
                        <td width="80px" >DISETUJUI</td>
                        <td >PERUBAHAN ****</td>
                        <td >DITANGGUHKAN ****</td>
                        <td width="276px" >TIDAK DISETUJUI ****</td>
                    </tr>
                    <tr>
                        <td ><?php if($detail->keputusan_wakil_direktur === 'DISETUJUI'): ?>Ya. <?php endif; ?></td>
                        <td ><?php if($detail->keputusan_wakil_direktur === 'PERUBAHAN'): ?>Ya. <?php echo e($detail->alasan_keputusan_wakil_direktur); ?><?php endif; ?></td>
                        <td ><?php if($detail->keputusan_wakil_direktur === 'DITANGGUHKAN'): ?>Ya. <?php echo e($detail->alasan_keputusan_wakil_direktur); ?><?php endif; ?></td>
                        <td ><?php if($detail->keputusan_wakil_direktur === 'TIDAK DISETUJUI'): ?>Ya. <?php echo e($detail->alasan_keputusan_wakil_direktur); ?><?php endif; ?></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: left; border-left: 0px solid; border-bottom: 0px solid;"></td>
                        <td style="text-align: center; border-top: 1px solid #424141; border-bottom: 1px solid #424141; border-left: 1px solid #424141;">
                            Hormat saya,
                            <br>
                            <?php if($detail->wakil_direktur !== null): ?>
                                <img src="https://himmi-polsub.com/gambar/tanda_tangan/wadir.png" width="29%" alt="">
                            <?php endif; ?>
                            <br>
                            ( <?php if($detail->wakil_direktur === null): ?> .............................................. <?php else: ?> <?php echo e($detail->wakil_direktur); ?> <?php endif; ?> ) <br>
                            NIP NIP <?php if($detail->nip_wakil_direktur === null): ?> .............................................. <?php else: ?> <?php echo e($detail->nip_wakil_direktur); ?> <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </section>
	</body>
</html><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/admin/cetak/cetak_pengajuan_cuti.blade.php ENDPATH**/ ?>