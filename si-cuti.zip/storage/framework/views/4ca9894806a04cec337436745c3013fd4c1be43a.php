

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-box">
                    <div class="form-title-wrap">
                        <div>
                            <h3 class="title"><?php echo e($subTitle); ?></h3>
                            <p class="font-size-14">Form <?php echo e($subTitle); ?></p>
                        </div>
                    </div>
                    <div class="form-content">
                        <div class="contact-form-action">
                            <form action="<?php if($user->role == 'Pegawai'): ?> /tambah-pengajuan-cuti <?php elseif($user->role == 'Ketua Jurusan'): ?> /tambah-pengajuan-cuti-ketua-jurusan <?php endif; ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-12 text-center">
                                        <div class="input-box">
                                            <label class="label-text"><strong>FORMULIR PERMINTAAN DAN PEMBERIAN CUTI</strong></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text"><strong>Data Pegawai</strong></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Nama</label>
                                            <div class="form-group">
                                                <input class="form-control" type="hidden" name="id_pegawai" value="<?php echo e($pegawai->id_pegawai); ?>" readonly>
                                                <input class="form-control" type="text" name="nama" placeholder="Masukkan Nama" value="<?php echo e($pegawai->nama); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>          
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">NIP</label>
                                            <div class="form-group">
                                                <input class="form-control" type="number" name="nip" placeholder="Masukkan NIP" value="<?php echo e($pegawai->nip); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Jabatan</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="jabatan" placeholder="Masukkan Jabatan" value="<?php echo e($pegawai->jabatan); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Masa Kerja</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="masa_kerja" placeholder="Masukkan Masa Kerja" value="<?php echo e($pegawai->masa_kerja); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['masa_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Unit Kerja</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="unit_kerja" placeholder="Masukkan Unit Kerja" value="<?php echo e($pegawai->unit_kerja); ?> POLITEKNIK NEGERI SUBANG" readonly>
                                            </div>
                                            <?php $__errorArgs = ['unit_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text"><strong>Jenis Cuti Yang Diambil **</strong></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text">Pilih Salah Satu</label>
                                            <div class="form-group d-flex align-items-center">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <label for="cuti_tahunan" class="radio-trigger mb-0 font-size-14 mr-3">
                                                            <input type="radio" id="cuti_tahunan" name="jenis_cuti" value="Cuti Tahunan">
                                                            <span class="checkmark"></span>
                                                            <span>1. Cuti Tahunan</span>
                                                        </label>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="cuti_besar" class="radio-trigger mb-0 font-size-14 mr-3">
                                                            <input type="radio" id="cuti_besar" name="jenis_cuti" value="Cuti Besar">
                                                            <span class="checkmark"></span>
                                                            <span>2. Cuti Besar</span>
                                                        </label>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="cuti_sakit" class="radio-trigger mb-0 font-size-14 mr-3">
                                                            <input type="radio" id="cuti_sakit" name="jenis_cuti" value="Cuti Sakit">
                                                            <span class="checkmark"></span>
                                                            <span>3. Cuti Sakit</span>
                                                        </label>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="cuti_melahirkan" class="radio-trigger mb-0 font-size-14">
                                                            <input type="radio" id="cuti_melahirkan" name="jenis_cuti" value="Cuti Melahirkan">
                                                            <span class="checkmark"></span>
                                                            <span>4. Cuti Melahirkan</span>
                                                        </label>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="cuti_karena_alasan_penting" class="radio-trigger mb-0 font-size-14">
                                                            <input type="radio" id="cuti_karena_alasan_penting" name="jenis_cuti" value="Cuti Karena Alasan Penting">
                                                            <span class="checkmark"></span>
                                                            <span>5. Cuti Karena Alasan Penting</span>
                                                        </label>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label for="cuti_di_luar_tanggungan_negara" class="radio-trigger mb-0 font-size-14">
                                                            <input type="radio" id="cuti_di_luar_tanggungan_negara" name="jenis_cuti" value="Cuti di Luar Tanggungan Negara">
                                                            <span class="checkmark"></span>
                                                            <span>6. Cuti di Luar Tanggungan Negara</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['jenis_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text"><strong>Alasan Cuti</strong></label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="alasan_cuti" placeholder="Masukkan Alasan Cuti" value="<?php echo e(old('alasan_cuti')); ?>">
                                            </div>
                                            <?php $__errorArgs = ['alasan_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text"><strong>Lamanya Cuti</strong></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Selama</label>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="form-group">
    
                                                        <input class="form-control" type="number" name="lama_cuti" value="<?php echo e(old('lama_cuti')); ?>">
                                                    </div>
                                                    <?php $__errorArgs = ['lama_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div style="margin-top: -16px">
                                                        <small class="text-danger"><?php echo e($message); ?></small>
                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group select-contain w-100">
                                                        <select class="select-contain-select" name="jenis_waktu">
                                                            <option value="hari">hari</option>
                                                            <option value="minggu">minggu</option>
                                                            <option value="bulan">bulan</option>
                                                            <option value="tahun">tahun</option>
                                                        </select>
                                                    </div>
                                                    <?php $__errorArgs = ['jenis_waktu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div style="margin-top: -16px">
                                                        <small class="text-danger"><?php echo e($message); ?></small>
                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Tanggal Cuti</label>
                                            <div class="form-group d-flex align-items-center">
                                                <input class="form-control pl-3" type="date" name="mulai_tanggal" placeholder="Tanggal Mulai" required>
                                                <span class="px-2">s/d</span>
                                                <input class="form-control pl-3" type="date" name="akhir_tanggal" placeholder="Tanggal Akhir" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text"><strong>Catatan Cuti</strong></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Sisa Cuti 2 Tahun Sebelumnya (N-2)</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="cuti_n_2" placeholder="Masukkan N-2" value="<?php echo e($pegawai->cuti_n_2); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['cuti_n_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Keterangan Sisa Cuti 2 Tahun Sebelumnya (N-2)</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="keterangan_n_2" placeholder="Masukkan Keterangan N-2" value="<?php echo e($pegawai->keterangan_n_2); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['keterangan_n_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Sisa Cuti 1 Tahun Sebelumnya (N-1)</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="cuti_n_1" placeholder="Masukkan N-1" value="<?php echo e($pegawai->cuti_n_1); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['cuti_n_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Keterangan Sisa Cuti 1 Tahun Sebelumnya (N-1)</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="keterangan_n_1" placeholder="Masukkan Keterangan N-1" value="<?php echo e($pegawai->keterangan_n_1); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['keterangan_n_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Sisa Cuti Tahun Berjalan (N)</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="cuti_n" placeholder="Masukkan N" value="<?php echo e($pegawai->cuti_n); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['cuti_n'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Keterangan Sisa Cuti Tahun Berjalan (N)</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="keterangan_n" placeholder="Masukkan Keterangan N" value="<?php echo e($pegawai->keterangan_n); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['keterangan_n'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Cuti Besar</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="cuti_besar" placeholder="Masukkan Cuti Besar" value="<?php echo e($pegawai->cuti_besar); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['cuti_besar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Cuti Sakit</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="cuti_sakit" placeholder="Masukkan Cuti Sakit" value="<?php echo e($pegawai->cuti_sakit); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['cuti_sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Cuti Melahirkan</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="cuti_melahirkan" placeholder="Masukkan Cuti Melahirkan" value="<?php echo e($pegawai->cuti_melahirkan); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['cuti_melahirkan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Cuti Karena Alasan Penting</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="cuti_karena_alasan_penting" placeholder="Masukkan Cuti Karena Alasan Penting" value="<?php echo e($pegawai->cuti_karena_alasan_penting); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['cuti_karena_alasan_penting'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Cuti Di Luar Tanggungan Negara</label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="cuti_diluar_tanggungan_negara" placeholder="Masukkan Cuti Di Luar Tanggungan Negara" value="<?php echo e($pegawai->cuti_diluar_tanggungan_negara); ?>" readonly>
                                            </div>
                                            <?php $__errorArgs = ['cuti_diluar_tanggungan_negara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text"><strong>Alamat Selama Menjalankan Cuti</strong></label>
                                            <div class="form-group">
                                                <input class="form-control" type="text" name="alamat_selama_cuti" placeholder="Masukkan Alamat Selama Menjalankan Cuti" value="<?php echo e(old('alamat_selama_cuti')); ?>">
                                            </div>
                                            <?php $__errorArgs = ['alamat_selama_cuti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div style="margin-top: -16px">
                                                <small class="text-danger"><?php echo e($message); ?></small>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mt-3 text-center">
                                    <a href="/pengajuan-cuti" class="theme-btn theme-btn-small theme-btn-transparent">Kembali</a>
                                    <button type="submit" class="theme-btn theme-btn-small">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div><!-- end form-box -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        
        
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/pegawai/pengajuancuti/add.blade.php ENDPATH**/ ?>