

<?php $__env->startSection('content'); ?>

<!-- ================================
    START BREADCRUMB AREA
================================= -->
<section class="breadcrumb-area bread-bg-10">
    <div class="breadcrumb-wrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-content text-center">
                        <div class="section-heading">
                            <h2 class="sec__title text-white"><?php echo e($title); ?></h2>
                        </div>
                        <span class="arrow-blink">
                            <i class="la la-arrow-down"></i>
                        </span>
                    </div><!-- end breadcrumb-content -->
                </div><!-- end col-lg-12 -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end breadcrumb-wrap -->
    <div class="bread-svg-box">
        <svg class="bread-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 10" preserveAspectRatio="none"><polygon points="100 0 50 10 0 0 0 10 100 10"></polygon></svg>
    </div><!-- end bread-svg -->
</section><!-- end breadcrumb-area -->
<!-- ================================
    END BREADCRUMB AREA
================================= -->

<!-- ================================
    START CART AREA
================================= -->
<section class="cart-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="cart-wrap">
                    <div class="row mb-5">
                        <div class="col-lg-4 mr-auto">
                            <div class="cart-totals table-form">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col" colspan="2">Riwayat</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">
                                                <div class="table-content">
                                                    <h3 class="title">Total Pesanan</h3>
                                                </div>
                                            </th>
                                            <td><?php echo e($jumlahOrder); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="section-block"></div>
                                <div class="btn-box text-right pt-4">
                                    <a href="/booking" class="theme-btn">Booking Saya</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-2 justify-content-end">
                        <div class="col-lg-2">
                            <div class="card">
                                <div class="card-header bg-primary text-white text-center">
                                    <b>Jam : <span id="jam"></span>:<span id="menit"></span>:<span id="detik"></span></b>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-lg-12">
                            <div class="mb-2">
                                <?php if(session('berhasil')): ?>    
                                    <div class="alert bg-primary text-white alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <?php echo e(session('berhasil')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-form table-responsive mb-3" >
                        <table class="table" id="example2">
                            <thead>
                                <tr>
                                    <th scope="col" style="width: 10px">No</th>
                                    <th scope="col">Reklame</th>
                                    <th scope="col">Harga</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no =1;?>
                                <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <th scope="row">
                                        <div class="table-content product-content d-flex align-items-center">
                                            <a href="#" class="d-block">
                                                <img src="<?php echo e(asset('foto_reklame/'.$item->gambar)); ?>" alt="" class="flex-shrink-0">
                                            </a>
                                        <div class="product-content">
                                            <a href="room-details.html" class="title">Lokasi: <?php echo e($item->lokasi); ?></a>
                                            <div class="product-info-wrap">
                                                <div class="product-info line-height-24">
                                                    <span class="product-info-label">Ukuran:</span>
                                                    <span class="product-info-value"><?php echo e($item->ukuran); ?></span>
                                                </div><!-- end product-info -->
                                                <div class="product-info line-height-24">
                                                    <span class="product-info-label">Orientation Page:</span>
                                                    <span class="product-info-value"><?php echo e($item->orientation_page); ?></span>
                                                </div><!-- end product-info -->
                                                <div class="product-info line-height-24">
                                                    <span class="product-info-label">Target Audiens:</span>
                                                    <span class="product-info-value"><?php echo e($item->target_audiens); ?></span>
                                                </div><!-- end product-info -->
                                            </div>
                                        </div>
                                        </div>
                                    </th>
                                    <td>
                                        <?php if($item->harga !== null): ?>
                                            <?= 'Rp ' . number_format($item->harga, 2, ',', '.'); ?>
                                        <?php else: ?>
                                            Menunggu verifikasi dari Admin. Tunggu maksimal sampai jam <b><?php echo e($item->jam_harga); ?></b>. <br>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->status_order === 'Batal'): ?>
                                            <span class="badge badge-danger"><?php echo e($item->status_order); ?></td></span>
                                        <?php elseif($item->status_order === 'Dibayar'): ?>
                                            <span class="badge badge-success"><?php echo e($item->status_order); ?></td></span>
                                        <?php elseif($item->status_order === 'Dibooking'): ?>
                                            <span class="badge badge-info"><?php echo e($item->status_order); ?></td></span>
                                        <?php elseif($item->status_order === 'Approve/Tayang'): ?>
                                            <span class="badge badge-warning"><?php echo e($item->status_order); ?></td></span>
                                        <?php elseif($item->status_order === 'Selesai'): ?>
                                            <span class="badge badge-primary"><?php echo e($item->status_order); ?></td></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->status_order !== 'Batal'): ?>
                                        <a href="/download-invoice/<?php echo e($item->id_pesanan); ?>" class="theme-btn theme-btn-small" data-toggle="tooltip" data-placement="top" title="Download Invoice" onclick="return confirm('Klik Ok! Untuk Download Invoice.')"><i class="la la-download"></i></a>  
                                        <?php endif; ?>
                                        <a href="/detail-booking/<?php echo e($item->id_pesanan); ?>" class="theme-btn theme-btn-small" data-toggle="tooltip" data-placement="top" title="Detail"><i class="la la-eye"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="section-block"></div>
                </div><!-- end cart-wrap -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end cart-area -->
<!-- ================================
    END CART AREA
================================= -->
<script>
    window.setTimeout("waktu()", 1000);

    function waktu() {
        var waktu = new Date();
        setTimeout("waktu()", 1000);
        document.getElementById("jam").innerHTML = waktu.getHours();
        document.getElementById("menit").innerHTML = waktu.getMinutes();
        document.getElementById("detik").innerHTML = waktu.getSeconds();
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutUser.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/user/booking/riwayatBooking.blade.php ENDPATH**/ ?>