

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-box">
                    <div class="form-title-wrap">
                        <div>
                            <h3 class="title"><?php echo e($subTitle); ?></h3>
                            <p class="font-size-14">Silahkan kelola data konfirmasi pembayaran di tabel bawah!</p>
                        </div>
                    </div>
                    <div class="form-content">
                        <div class="table-form table-responsive">
                            <div class="mb-2">
                                <?php if(session('berhasil')): ?>    
                                    <div class="alert bg-primary text-white alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <h4><i class="icon fa fa-ban"></i> Berhasil!</h4>
                                        <?php echo e(session('berhasil')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <table class="table" id="example2">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">ID Pesanan</th>
                                        <th scope="col">Member</th>
                                        <th scope="col">Reklame</th>
                                        <th scope="col">Tanggal Bayar</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;?>
                                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($no++); ?></th>
                                            <th><?php echo e($item->id_pesanan); ?></th>
                                            <td><?php echo e($item->nama); ?></td>
                                            <td><?php echo e($item->lokasi); ?></td>
                                            <td><?php echo e($item->tanggal_bayar); ?></td>
                                            <td>
                                                <?php if($item->status_order === 'Batal'): ?>
                                                    <span class="badge badge-danger"><?php echo e($item->status_order); ?></td></span>
                                                <?php elseif($item->status_order === 'Dibooking'): ?>
                                                    <span class="badge badge-info"><?php echo e($item->status_order); ?></td></span>
                                                <?php elseif($item->status_order === 'Dibayar'): ?>
                                                    <span class="badge badge-success"><?php echo e($item->status_order); ?></td></span>
                                                <?php elseif($item->status_order === 'Approve/Tayang'): ?>
                                                    <span class="badge badge-warning"><?php echo e($item->status_order); ?></td></span>
                                                <?php elseif($item->status_order === 'Selesai'): ?>
                                                    <span class="badge badge-primary"><?php echo e($item->status_order); ?></td></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="table-content">
                                                    <button type="button" class="theme-btn theme-btn-small" data-toggle="modal" data-target="#editStatus<?php echo e($item->id_pesanan); ?>" data-toggle="tooltip" data-placement="top" title="Edit Status Order"><i class="la la-check"></i></button>
                                                    <a href="/detail-pembayaran/<?php echo e($item->id_konfirmasi_pembayaran); ?>" class="theme-btn theme-btn-small" data-toggle="tooltip" data-placement="top" title="Detail"><i class="la la-eye"></i></a>
                                                    <button type="button" data-toggle="modal" data-target="#hapus<?php echo e($item->id_konfirmasi_pembayaran); ?>" class="theme-btn theme-btn-small" data-toggle="tooltip" data-placement="top" title="Hapus"><i class="la la-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div><!-- end form-box -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->

        
        <?php echo $__env->make('layoutAdmin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>

<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editStatus<?php echo e($item->id_pesanan); ?>"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content modal-sm">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit Status Order</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <form action="/edit-status/<?php echo e($item->id_pesanan); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="input-box">
                            <label class="label-text">Status</label>
                            <div class="form-group select-contain w-100">
                                <select class="select-contain-select" name="status_order">
                                    <option value="<?php echo e($item->status_order); ?>"><?php echo e($item->status_order); ?></option>
                                    <option value="Dibayar">Dibayar</option>
                                    <option value="Approve/Tayang">Approve/Tayang</option>
                                    <option value="Selesai">Selesai</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
        </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="hapus<?php echo e($item->id_konfirmasi_pembayaran); ?>"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <p>Apakah Anda yakin akan hapus data ini ?</p>
                    </div>
                </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
            <a href="/hapus-pembayaran/<?php echo e($item->id_konfirmasi_pembayaran); ?>"class="btn btn-danger">Hapus</a>
        </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layoutAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/admin/konfirmasiPembayaran/dataKonfirmasiPembayaran.blade.php ENDPATH**/ ?>