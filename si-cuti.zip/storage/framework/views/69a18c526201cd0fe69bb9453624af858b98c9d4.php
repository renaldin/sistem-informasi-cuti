

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row mt-4" style="margin-bottom: 25vh;">
            <div class="col-lg-12 ">
                <div class="icon-box icon-layout-2 dashboard-icon-box pb-3">
                    <div class="d-flex pb-3 justify-content-between">
                        <div class="info-content">
                            <p class="info__desc">Selamat datang <?php echo e($user->nama); ?>. Selamat datang di website <?php echo e($biodata->nama_website); ?>.</p>
                        </div><!-- end info-content -->
                    </div>
                </div>
            </div><!-- end col-lg-3 -->
        </div>
        <br>
        <br>
        <br>
        <br>
        
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/bagianumum/dashboard.blade.php ENDPATH**/ ?>