

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-box">
                    <div class="form-title-wrap">
                        <div>
                            <h3 class="title"><?php echo e($subTitle); ?></h3>
                            <p class="font-size-14">Silahkan kelola data absensi di tabel bawah!</p>
                        </div>
                    </div>
                    <div class="form-content">
                        <div class="table-form table-responsive">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <button type="button" class="theme-btn theme-btn-small" data-toggle="modal" data-target="#absen"><i class="la la-plus"></i> Tambah</button>
                                    
                                </div>
                            </div>
                            <div class="mb-2">
                                <?php if(session('berhasil')): ?>    
                                    <div class="alert bg-primary text-white alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <h4><i class="icon fa fa-ban"></i> Berhasil!</h4>
                                        <?php echo e(session('berhasil')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('gagal')): ?>    
                                    <div class="alert bg-danger text-white alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <h4><i class="icon fa fa-ban"></i> Gagal!</h4>
                                        <?php echo e(session('gagal')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <table class="table" id="example2">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Masuk</th>
                                        <th scope="col">Pulang</th>
                                        <th scope="col">Keterangan</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;?>
                                    <?php $__currentLoopData = $dataAbsensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($no++); ?></th>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->masuk); ?></td>
                                        <td><?php echo e($item->pulang); ?></td>
                                        <?php if($item->keterangan == null): ?>
                                            <td>Tidak Ada</td>
                                        <?php else: ?>
                                            <td><?php echo e($item->keterangan); ?></td>
                                        <?php endif; ?>
                                        <td>
                                            <div class="table-content">
                                                <button type="button" data-toggle="modal" data-target="#detail<?php echo e($item->id_absensi); ?>" class="theme-btn theme-btn-small mb-1" data-toggle="tooltip" data-placement="top" title="Detail"><i class="la la-eye"></i></button>
                                                <button type="button" data-toggle="modal" data-target="#edit<?php echo e($item->id_absensi); ?>" class="theme-btn theme-btn-small mb-1" data-toggle="tooltip" data-placement="top" title="Edit"><i class="la la-edit"></i></button>   
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div><!-- end form-box -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>


<div class="modal fade" id="absen"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <center>
                <button type="button" class="theme-btn theme-btn-small" data-toggle="modal" data-target="#tambah"><i class="la la-plus"></i> Tambah Satu</button>
                <button type="button" class="theme-btn theme-btn-small" data-toggle="modal" data-target="#import"><i class="la la-plus"></i> Import</button>
            </center>
        </div>
        <div class="modal-footer">
        </div>
        </form>
        </div>
    </div>
</div>



<div class="modal fade" id="import"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Import Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
                <form action="/import-absensi" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="input-box">
                        <label class="label-text">File Excel</label>
                        <div class="form-group">
                            <input class="form-control" type="file" name="file" placeholder="Masukkan File Excel" required>
                        </div>
                    </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
            <button type="submit" class="btn btn-primary">Import</button>
        </div>
        </form>
        </div>
    </div>
</div>



<div class="modal fade" id="tambah"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
                <form action="/tambah-absensi" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="input-box">
                                <label class="label-text">Pegawai</label>
                                <div class="form-group select-contain w-100">
                                    <select class="select2 form-control" style="width: 100%" name="id_pegawai" required>
                                        <option value="">-- Pilih Pegawai --</option>
                                        <?php $__currentLoopData = $dataPegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id_pegawai); ?>"><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="input-box">
                                <label class="label-text">Tanggal</label>
                                <div class="form-group">
                                    <input class="form-control" type="date" name="tanggal" placeholder="Masukkan Tanggal" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="input-box">
                                <label class="label-text">Tanggal Masuk</label>
                                <div class="form-group">
                                    <input class="form-control" type="datetime-local" name="masuk" placeholder="Masukkan Tanggal Masuk" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="input-box">
                                <label class="label-text">Tanggal Pulang</label>
                                <div class="form-group">
                                    <input class="form-control" type="datetime-local" name="pulang" placeholder="Masukkan Tanggal Masuk">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="input-box">
                                <label class="label-text">Keterangan</label>
                                <div class="form-group">
                                    <input class="form-control" type="text" name="keterangan" placeholder="Masukkan Keterangan" required>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
        </form>
        </div>
    </div>
</div>



<?php $__currentLoopData = $dataAbsensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="edit<?php echo e($item->id_absensi); ?>"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
                <form action="/edit-absensi/<?php echo e($item->id_absensi); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="input-box">
                        <label class="label-text">Nama Lengkap</label>
                        <div class="form-group">
                            <input class="form-control" type="text" name="nama" placeholder="Masukkan Nama" value="<?php echo e($item->nama); ?>" required>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text">NIP/NIK</label>
                        <div class="form-group">
                            <input class="form-control" type="text" name="nip" placeholder="Masukkan NIP/NIK" value="<?php echo e($item->nip); ?>" required>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text">Tanggal</label>
                        <div class="form-group">
                            <input class="form-control" type="date" name="tanggal" placeholder="Masukkan Tanggal" value="<?php echo e($item->tanggal); ?>" required>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text">Tanggal Masuk</label>
                        <div class="form-group">
                            <input class="form-control" type="datetime-local" name="masuk" placeholder="Masukkan Tanggal Masuk" value="<?php echo e($item->masuk); ?>" required>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text">Tanggal Pulang</label>
                        <div class="form-group">
                            <input class="form-control" type="datetime-local" name="pulang" placeholder="Masukkan Tanggal Masuk" value="<?php echo e($item->pulang); ?>">
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text">Keterangan</label>
                        <div class="form-group">
                            <input class="form-control" type="text" name="keterangan" placeholder="Masukkan Keterangan" value="<?php echo e($item->keterangan); ?>" required>
                        </div>
                    </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
        </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__currentLoopData = $dataAbsensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="detail<?php echo e($item->id_absensi); ?>"  role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Detail Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-lg-12">
                    <table>
                        <tr>
                            <th width="150px">Nama</th>
                            <td width="20px" class="text-center">:</td>
                            <td><?php echo e($item->nama); ?></td>
                        </tr>
                        <tr>
                            <th width="150px">NIP/NIK</th>
                            <td width="20px" class="text-center">:</td>
                            <td><?php echo e($item->nip); ?></td>
                        </tr>
                        <tr>
                            <th>Tanggal Absensi</th>
                            <td>:</td>
                            <td><?php echo e($item->tanggal); ?></td>
                        </tr>
                        <tr>
                            <th>Masuk</th>
                            <td>:</td>
                            <td><?php echo e($item->masuk); ?></td>
                        </tr>
                        <tr>
                            <th>Pulang</th>
                            <td>:</td>
                            <td><?php echo e($item->pulang); ?></td>
                        </tr>
                        <tr>
                            <th>Keterangan</th>
                            <td>:</td>
                            <td><?php echo e($item->keterangan); ?></td>
                        </tr>
                        <?php if($item->alasan): ?>
                        <tr>
                            <th>Alasan</th>
                            <td>:</td>
                            <td><?php echo e($item->alasan); ?></td>
                        </tr>
                            
                        <?php endif; ?>
                    </table>
                </div>
                <?php if($item->file_absensi): ?>
                    <div class="col-lg-12 mt-3 text-center">
                        <label class="label-text">File Surat</label>
                        <iframe src="<?php echo e(asset('file_absensi/'.$item->file_absensi)); ?>" frameborder="0" scrolling="auto" width="100%" height="500px"></iframe>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
        </div>
        </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/admin/absensi/data.blade.php ENDPATH**/ ?>