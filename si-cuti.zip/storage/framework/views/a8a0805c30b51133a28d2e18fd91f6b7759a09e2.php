

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-box">
                    <div class="form-title-wrap">
                        <div>
                            <h3 class="title"><?php echo e($subTitle); ?></h3>
                            <p class="font-size-14">Silahkan lihat riwayat data pengajuan cuti di tabel bawah!</p>
                        </div>
                    </div>
                    <div class="form-content">
                        <div class="table-form table-responsive">
                            <div class="mb-2">
                                <?php if(session('berhasil')): ?>
                                <div class="alert bg-primary text-white alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <h4><i class="icon fa fa-ban"></i> Berhasil!</h4>
                                    <?php echo e(session('berhasil')); ?>

                                </div>
                                <?php endif; ?>
                                <?php if(session('gagal')): ?>
                                <div class="alert bg-danger text-white alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <h4><i class="icon fa fa-ban"></i> Gagal!</h4>
                                    <?php echo e(session('gagal')); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                            <table class="table" id="example2">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Jenis Cuti</th>
                                        <th scope="col">Dari Atasan</th>
                                        <th scope="col">Dari Pejabat</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1; ?>
                                    <?php $__currentLoopData = $dataPengajuanCuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($no++); ?></th>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->jenis_cuti); ?></td>
                                        <td><?php echo e($item->pertimbangan_ketua_jurusan); ?></td>
                                        <td><?php echo e($item->keputusan_wakil_direktur); ?></td>
                                        <td>
                                            <div class="table-content">
                                                <a href="<?php if($user->role == 'Pegawai'): ?>/detail-pengajuan-cuti/<?php echo e($item->id_pengajuan_cuti); ?><?php elseif($user->role == 'Ketua Jurusan'): ?>/detail-pengajuan-cuti-ketua-jurusan/<?php echo e($item->id_pengajuan_cuti); ?><?php endif; ?>" class="theme-btn theme-btn-small mb-1" data-toggle="tooltip" data-placement="top" title="Detail"><i class="la la-eye"></i></a>
                                                <a href="<?php if($user->role == 'Pegawai'): ?>/download-riwayat-pengajuan-cuti/<?php echo e($item->id_pengajuan_cuti); ?><?php elseif($user->role == 'Ketua Jurusan'): ?>/download-riwayat-pengajuan-cuti-ketua-jurusan/<?php echo e($item->id_pengajuan_cuti); ?><?php endif; ?>" class="theme-btn theme-btn-small mb-1" data-toggle="tooltip" data-placement="top" title="Download"><i class="la la-download"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div><!-- end form-box -->
            </div><!-- end col-lg-12 -->
        </div><!-- end row -->
        
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/pegawai/pengajuancuti/history.blade.php ENDPATH**/ ?>