<div class="sidebar-nav sidebar--nav">
    <div class="sidebar-nav-body">
        <div class="author-content">
            <div class="d-flex align-items-center">
                <div class="author-img avatar-sm">
                    <img src="<?php if($user->foto): ?><?php echo e(asset('foto_user/'.$user->foto)); ?> <?php else: ?> <?php echo e(asset('foto_user/default1.jpg')); ?> <?php endif; ?>" alt="testimonial image">
                </div>
                <div class="author-bio">
                    <h4 class="author__title"><?php echo e($user->nama); ?></h4>
                    <span class="author__meta">Welcome to <?php echo e($user->role); ?> Panel</span>
                </div>
            </div>
        </div>
        <div class="sidebar-menu-wrap">
            <ul class="sidebar-menu toggle-menu list-items">
                <?php if(Session()->get('role') === 'Admin'): ?>
                    <li class="<?php if($subTitle === 'Dashboard'): ?> page-active <?php endif; ?>"><a href="/dashboardAdmin"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
                    <li class="<?php if($subTitle === 'Setting'): ?> page-active <?php endif; ?>"><a href="/setting"><i class="la la-laptop mr-2"></i>Setting</a></li>
                    <li class="<?php if($title === 'Data Pegawai'): ?> page-active <?php endif; ?>" ><a href="/kelola-pegawai"><i class="la la-users mr-2"></i>Kelola Pegawai</a></li>
                    
                    <li class="<?php if($title === 'Data Absensi'): ?> page-active <?php endif; ?>" ><a href="/kelola-absensi"><i class="la la-list mr-2"></i>Kelola Absensi</a></li>
                    <li class="<?php if($title === 'Data Surat'): ?> page-active <?php endif; ?>" ><a href="/kelola-surat"><i class="la la-file mr-2"></i>Kelola Surat</a></li>
                    <li class="<?php if($title === 'Data Artikel'): ?> page-active <?php endif; ?>" ><a href="/kelola-artikel"><i class="la la-folder-o mr-2"></i>Kelola Artikel</a></li>
                    <li class="<?php if($title === 'Pengajuan Cuti'): ?> page-active <?php endif; ?>" ><a href="/kelola-pengajuan-cuti"><i class="la la-bookmark-o mr-2"></i>Kelola Pengajuan Cuti</a></li>
                    
                <?php elseif(Session()->get('role') === 'Pegawai'): ?>
                    <li class="<?php if($subTitle === 'Dashboard'): ?> page-active <?php endif; ?>"><a href="/dashboardPegawai"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
                    <li class="<?php if($title === 'Pengajuan Cuti'): ?> page-active <?php endif; ?>" ><a href="/pengajuan-cuti"><i class="la la-bookmark-o mr-2"></i>Pengajuan Cuti</a></li>
                    <li class="<?php if($title === 'Riwayat Pengajuan Cuti'): ?> page-active <?php endif; ?>" ><a href="/riwayat-pengajuan-cuti"><i class="la la-map-signs mr-2"></i>Riwayat Pengajuan Cuti</a></li>
                    
                    <li class="<?php if($title === 'Data Absensi'): ?> page-active <?php endif; ?>" ><a href="/lihat-absensi"><i class="la la-list mr-2"></i>Riwayat Absensi</a></li>
                    <li class="<?php if($title === 'Data Surat'): ?> page-active <?php endif; ?>" ><a href="/lihat-surat"><i class="la la-list mr-2"></i>Riwayat Surat Tugas</a></li>
                    
                    <?php elseif(Session()->get('role') === 'Wakil Direktur'): ?>
                    <li class="<?php if($subTitle === 'Dashboard'): ?> page-active <?php endif; ?>"><a href="/dashboardWakilDirektur"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
                    
                    <li class="<?php if($title === 'Perizinan Cuti'): ?> page-active <?php endif; ?>" ><a href="/perizinan-cuti-wakil-direktur"><i class="la la-bookmark-o mr-2"></i>Perizinan Cuti</a></li>
                    <li class="<?php if($title === 'Data Absensi'): ?> page-active <?php endif; ?>" ><a href="/lihat-absensi"><i class="la la-list mr-2"></i>Riwayat Absensi</a></li>
                    <li class="<?php if($title === 'Data Surat'): ?> page-active <?php endif; ?>" ><a href="/lihat-surat"><i class="la la-list mr-2"></i>Riwayat Surat Tugas</a></li>
                    
                    
                    <?php elseif(Session()->get('role') === 'Ketua Jurusan'): ?>
                    <li class="<?php if($subTitle === 'Dashboard'): ?> page-active <?php endif; ?>"><a href="/dashboardKetuaJurusan"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
                    <li class="<?php if($title === 'Perizinan Cuti'): ?> page-active <?php endif; ?>" ><a href="/perizinan-cuti-ketua-jurusan"><i class="la la-bookmark-o mr-2"></i>Perizinan Cuti</a></li>
                    <li class="<?php if($title === 'Data Absensi'): ?> page-active <?php endif; ?>" ><a href="/lihat-absensi"><i class="la la-list mr-2"></i>Riwayat Absensi</a></li>
                    <li class="<?php if($title === 'Data Surat'): ?> page-active <?php endif; ?>" ><a href="/lihat-surat"><i class="la la-list mr-2"></i>Riwayat Surat Tugas</a></li>
                    <li class="<?php if($title === 'Pengajuan Cuti'): ?> page-active <?php endif; ?>" ><a href="/pengajuan-cuti-ketua-jurusan"><i class="la la-bookmark-o mr-2"></i>Pengajuan Cuti</a></li>
                    <li class="<?php if($title === 'Riwayat Pengajuan Cuti'): ?> page-active <?php endif; ?>" ><a href="/riwayat-pengajuan-cuti-ketua-jurusan"><i class="la la-map-signs mr-2"></i>Riwayat Pengajuan Cuti</a></li>
            
                <?php elseif(Session()->get('role') === 'Bagian Umum'): ?>
                    <li class="<?php if($subTitle === 'Dashboard'): ?> page-active <?php endif; ?>"><a href="/dashboardBagianUmum"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
                    <li class="<?php if($title === 'Data Surat'): ?> page-active <?php endif; ?>" ><a href="/kelola-surat"><i class="la la-file mr-2"></i>Kelola Surat</a></li>
                    
                <?php endif; ?>
                <li><a data-toggle="modal" data-target="#logout"><i class="la la-power-off mr-2"></i>Logout</a></li>
            </ul>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\si-cuti\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>