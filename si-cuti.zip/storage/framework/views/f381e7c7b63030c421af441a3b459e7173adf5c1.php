

<?php $__env->startSection('content'); ?>
<section>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-box">
                <div class="form-title-wrap">
                    <div>
                        <h3 class="title"><?php echo e($subTitle); ?></h3>
                        <p class="font-size-14">Silahkan beri harga untuk ID Pesanan <?php echo e($order->id_pesanan); ?></p>
                    </div>
                </div>
                <div class="form-content">
                    <div class="contact-form-action">
                        <form action="/beri-harga/<?php echo e($order->id_pesanan); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="input-box">
                                        <label class="label-text">Harga</label>
                                        <div class="form-group">
                                            <span class="la la-circle form-icon"></span>
                                            <input class="form-control" type="number" name="harga" placeholder="Masukkan Harga" <?php if($form === 'Edit'): ?> value="<?php echo e($order->harga); ?>" <?php else: ?> value="<?php echo e(old('harga')); ?>" <?php endif; ?> autofocus>
                                        </div>
                                        <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div style="margin-top: -16px">
                                            <small class="text-danger"><?php echo e($message); ?></small>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="btn-box pt-3 pb-4">
                                <button type="submit" class="theme-btn">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!-- end form-box -->
        </div><!-- end col-lg-12 -->
    </div><!-- end row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutAdmin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistem-booking-billboard\resources\views/admin/order/formHarga.blade.php ENDPATH**/ ?>